import { Injectable } from '@nestjs/common';

import { Cart } from '../models';
import { createConnectionToDB } from '@db/config';

export const GET_CART_LIST_QUERY = `select * from carts where user_id = $1`;
export const GET_CART_ITEMS_LIST_QUERY = `select * from cart_items where cart_id = $1`;
export const GET_CART_BY_ID_QUERY = `select * from cart_items where cart_id = $1 and user_id = $2`;

export const UPDATE_COUNT_CART_BY_ID_QUERY = `update cart_items set count = $3 where (cart_id IN (SELECT id FROM carts where user_id = $1) AND product_id = $2)  returning count`;

export const DELETE_CART_QUERY = `delete from carts where user_id = $1 returning *`;
export const DELETE_CART_ITEMS_QUERY = `delete from cart_items where cart_id IN (SELECT id FROM carts where user_id = $1) returning *`;

@Injectable()
export class CartService {
  private dbClient;

  async findByUserId(userId: string): Promise<Cart> {
    try {
      this.dbClient = await createConnectionToDB();
      const cart = await this.dbClient.query(GET_CART_LIST_QUERY, [userId]);

      if (!cart) {
        throw new Error(`Cart not found`);
      }

      const items = await this.dbClient.query(GET_CART_ITEMS_LIST_QUERY, [
        cart.rows[0]?.id,
      ]);

      return { id: cart.rows[0]?.id, items: items.rows };
    } catch (err) {
      console.log('Error on service getCarts: ', err);
      return err;
    }
  }

  async updateByUserId(
    userId: string,
    { productId, count },
  ): Promise<{ count: string }> {
    try {
      this.dbClient = await createConnectionToDB();

      const updatedItem = await this.dbClient.query(
        UPDATE_COUNT_CART_BY_ID_QUERY,
        [userId, productId, count],
      );

      return { count: updatedItem.rows[0].count };
    } catch (err) {
      console.log('Error on service updateCartItem: ', err);
      return err;
    }
  }

  async removeByUserId(userId): Promise<void> {
    try {
      this.dbClient = await createConnectionToDB();
      const cart_item = await this.dbClient.query(DELETE_CART_ITEMS_QUERY, [
        userId,
      ]);
      return cart_item.rows[0];
    } catch (err) {
      console.log('Error on service removeCartItem: ', err);
      return err;
    }
  }
}
